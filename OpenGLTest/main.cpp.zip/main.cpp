//
//  main.cpp
//  OpenGLTest
//
//  Created by 김성민 on 2020/03/07.
//  Copyright © 2020 Sung Min Kim. All rights reserved.
//

#define GL_SILENCE_DEPRECATION

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <stdbool.h>
#include <GL/glew.h>
#include "/Users/dodo4.0/Projects/OpenGL/CG_Term_Project/GLUT.framework/Headers/glut.h"
#include "/Users/dodo4.0/Projects/OpenGL/CG_Term_Project/OpenGLTest/LoadShaders.h"
#include "/Users/dodo4.0/Projects/OpenGL/CG_Term_Project/OpenGLTest/loadobj.h"

#include "/Users/dodo4.0/Projects/OpenGL/ode-0.16/include/ode/ode.h"
#include "/Users/dodo4.0/Projects/OpenGL/ode-0.16/include/ode/common.h"


#define _USE_MATH_DEFINES
#include <math.h>
#include <vector>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <time.h>

#define STB_IMAGE_IMPLEMENTATION
#include "/Users/dodo4.0/Projects/OpenGL/CG_Term_Project/OpenGLTest/stb_image.h"

#define UVAR(name) glGetUniformLocation(program, name)
#define MAP_FIND(map_obj, item)\
    ((map_obj).find(item) != (map_obj).end())

#define IS_MIPMAP(flag)\
    ((flag) == GL_LINEAR_MIPMAP_LINEAR || \
     (flag) == GL_LINEAR_MIPMAP_NEAREST || \
     (flag) == GL_NEAREST_MIPMAP_LINEAR || \
     (flag) == GL_NEAREST_MIPMAP_NEAREST)


#define NUM_OF_MODELS 3
#define WALL 3
#define CITY 2
#define PATRICK 0
#define CAR 1

typedef std::vector<GLfloat> GLvec;
using namespace glm;
using namespace std;
using namespace tinyobj;

GLuint program;
int shading_mode = 0;
bool isSportsCar = true ; // 나중에 바꿔줘
GLfloat acceleration_rate = 0.0f ;

/* City, Patrick, Audi */
const char* model_files [NUM_OF_MODELS] = {
    "/Users/dodo4.0/Projects/OpenGL/CG_Term_Project/OpenGLTest/project_obj/Patrick/Patrick.obj",
    "/Users/dodo4.0/Projects/OpenGL/CG_Term_Project/OpenGLTest/project_obj/Car/LEGO_CAR_B2.obj",
    "/Users/dodo4.0/Projects/OpenGL/CG_Term_Project/OpenGLTest/project_obj/City/serpentine city.obj"
};

const char* basedir [NUM_OF_MODELS] = {
    "/Users/dodo4.0/Projects/OpenGL/CG_Term_Project/OpenGLTest/project_obj/Patrick/",
    "/Users/dodo4.0/Projects/OpenGL/CG_Term_Project/OpenGLTest/project_obj/Car/",
    "/Users/dodo4.0/Projects/OpenGL/CG_Term_Project/OpenGLTest/project_obj/City/",
};

float model_scales[NUM_OF_MODELS] = {0.3f, 1.0f, 50.0f}; //{0.5f, 1.0f, 50.0f};

vector<real_t> vertices[NUM_OF_MODELS];
vector<real_t> normals[NUM_OF_MODELS];
vector<real_t> colors[NUM_OF_MODELS];
vector<vector<size_t>> vertex_map[NUM_OF_MODELS];
vector<vector<size_t>> material_map[NUM_OF_MODELS];
vector<shape_t> shapes[NUM_OF_MODELS];
vector<material_t> materials[NUM_OF_MODELS];
vector<real_t> texcoords[NUM_OF_MODELS];
map<string, size_t> texmap[NUM_OF_MODELS];

GLuint vao[NUM_OF_MODELS];
GLuint vbo[NUM_OF_MODELS][4];

bool is_obj_valid = false;
bool is_tex_valid = false;

// Direction Key offset for the object
GLfloat car_speed = 0.0f ;
GLfloat theta = 0.0f ;
GLfloat accel = 1.0f;

bool is_forward_pressed = false ;
bool is_back_pressed = false ;
bool is_left_pressed = false ;
bool is_right_pressed = false ;
bool is_booster_pressed = false ;
int cnt = 0 ;

#ifdef dSINGLE
#define dEpsilon FLT_EPSILON
#else
#define dEpsilon DBL_EPSILON
#endif

static dWorldID ode_world;
static dSpaceID ode_space;
static dJointGroupID ode_contactgroup;
static bool pause = true;

static dGeomID ode_plane_geom;

static dBodyID ode_sphere_body;
static dGeomID ode_sphere_geom;

static dBodyID ode_trimesh_body;
static dGeomID ode_trimesh_geom;
static dTriMeshDataID ode_trimesh_data;
static std::vector<dTriIndex> ode_trimesh_index;

int button_pressed[3] = {GLUT_UP, GLUT_UP, GLUT_UP};
int mouse_pos[2] = {0, 0};
void init();
void display();
int build_program();
void bind_buffer(GLint buffer, GLvec& vec, int program, const GLchar* attri_name, GLint attri_size);

/* Callback Functions */
void motion(int x, int y) ;
void mouse(int button, int state, int x, int y) ;
void special_key(int key, int x, int y) ;
void special_up(int key, int x, int y) ;
void keyboard(unsigned char key, int x, int y) ;

static bool has_file(const char* filepath);
bool load_tex(const char* basedir, vector<real_t>& texcoords_out, map<string, size_t>& texmap_out,
              const vector<real_t>& texcoords, const vector<shape_t>& shapes, const vector<material_t>& materials,
              GLint min_filter, GLint mag_filter);
void render(int color_mode);
void draw_obj_model(int model_idx, int color_mode, int object_code);
GLuint generate_tex( const char* tex_file_path, GLint min_filter, GLint mag_filter);

glm::mat4 parallel(double r, double aspect, double n, double f);

#define FPUSH_VTX3(p, vx, vy, vz)\
do{ \
    p.push_back(vx); \
    p.push_back(vy); \
    p.push_back(vz); \
} while(0)

#define FSET_VTX3(vx, vy, vz, valx, valy, valz)\
do{ \
    vx = (float)(valx); \
    vy = (float)(valy); \
    vz = (float)(valz); \
} while(0)

#define FPUSH_VTX3_AT(p,i,vx,vy,vz)\
do{ \
    GLuint i3 = 3*(i); \
    p[i3+0] = (float)(vx); \
    p[i3+1] = (float)(vy); \
    p[i3+2] = (float)(vz); \
} while(0)



struct Camera {
    enum { ORTHOGRAPHIC, PERSPECTIVE};
    glm::vec3 eye;
    glm::vec3 center;
    glm::vec3 up;
    float zoom_factor;
    int projection_mode;
    float z_near;
    float z_far;
    float fovy;
    float x_right;
    
    Camera() :eye(0, 0, 8), center(0, 0, 0), up(0, 1, 0), zoom_factor(1.0f), projection_mode(ORTHOGRAPHIC), z_near(0.01f),
                z_far(100.0f), fovy((float)(M_PI/180.0*(30.0))), x_right(1.2)
                {}
    glm::mat4 get_viewing() { return glm::lookAt(eye, center, up); }
    glm::mat4 get_projection(float aspect){
        glm::mat4 P;
        switch (projection_mode) {
            case ORTHOGRAPHIC:
                P = parallel(zoom_factor*x_right, aspect, z_near, z_far);
                break;
                
            case PERSPECTIVE:
                P = glm::perspective(zoom_factor*fovy, aspect, z_near, z_far);
                break;
        }
        return P;
    }
};

Camera camera;

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA |GLUT_DOUBLE| GLUT_DEPTH |GLUT_3_2_CORE_PROFILE);
    glutInitWindowSize(1024, 1024);
    glutCreateWindow(argv[0]);

    glewExperimental = GL_TRUE;
    GLenum err = glewInit();
    if (err != GLEW_OK){
        fprintf(stderr, "Error: %s\n", glewGetErrorString(err));
        exit(-1);
    }
    
    init();
    glutDisplayFunc(display);
    glutMouseFunc(mouse);
    glutMotionFunc(motion);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(special_key);
    glutSpecialUpFunc(special_up);
    glutIgnoreKeyRepeat(1);
    glutMainLoop();
}

void init(){
    program = build_program();
    
    dMatrix3 R;
    dMass m;
    dRSetIdentity(R);
    
    //createt world
    dInitODE2(0);
    ode_world = dWorldCreate();
    ode_space = dSimpleSpaceCreate(0);
    ode_contactgroup = dJointGroupCreate(0);
    dWorldSetGravity(ode_world, 0, -9.8, 0);
    
    //generate plane geometry
    ode_plane_geom = dCreatePlane(ode_space, 0, 1, 0, 0);
    
    //body
    ode_sphere_body = dBodyCreate(ode_world);
    dBodySetPosition(ode_sphere_body, 0, 2, 0);
    dBodySetRotation(ode_sphere_body, R);
    dBodySetLinearVel(ode_sphere_body, 0, 0, 0);
    dBodySetAngularVel(ode_sphere_body, 0, 0, 0);

    ode_sphere_geom = dCreateSphere(ode_space, 0.2f);
    dGeomSetBody(ode_sphere_geom, ode_sphere_body);
    dMassSetSphereTotal(&m, 20, 0.2f);
    dBodySetMass(ode_sphere_body, &m);
    cout << "ode_sphere_body success" << endl;
 
    ode_trimesh_body = dBodyCreate(ode_world);
    dBodySetPosition(ode_trimesh_body, 0, 0, 0);
    dBodySetRotation(ode_trimesh_body, R);
    dBodySetLinearVel(ode_trimesh_body, 0, 0, 0);
    dBodySetAngularVel(ode_trimesh_body, 0, 0, 0);
    
    for(size_t k = 0; k<NUM_OF_MODELS; ++k){
        attrib_t attrib;
        is_obj_valid = load_obj(model_files[k], basedir[k], vertices[k], normals[k], vertex_map[k], material_map[k], attrib, shapes[k], materials[k], model_scales[k]) ;
        
        glActiveTexture(GL_TEXTURE0);
        is_tex_valid = load_tex(basedir[k], texcoords[k], texmap[k], attrib.texcoords, shapes[k], materials[k], GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR_MIPMAP_LINEAR);
        
        
        if(!is_obj_valid)
            cout << ">>> Can't load the obj" << endl ;
        if(!is_tex_valid)
            cout << ">>> Can't load the tex" << endl ;

        colors[k].resize(vertices[k].size());
        for(int i=0; i<colors[k].size(); ++i){
            colors[k][i] = 1.0f;
        }
        
        printf("Loading %zu...\n", k);
        glGenVertexArrays(1, &vao[k]);
        glBindVertexArray(vao[k]);
        glGenBuffers(3, vbo[k]);
        bind_buffer(vbo[k][0], vertices[k], program, "vPosition", 3);
        bind_buffer(vbo[k][1], normals[k], program, "vNormal", 3);
        bind_buffer(vbo[k][2], texcoords[k], program, "vTexcoord", 2);
        printf("END!!\n");
    }
    
    int n = (int)(vertices[0].size() / 3);
    ode_trimesh_index.resize(n);
    for(int i = 0; i<n; ++i) ode_trimesh_index[i] = i;

    ode_trimesh_data = dGeomTriMeshDataCreate();
    dGeomTriMeshDataBuildSingle(ode_trimesh_data, vertices[0].data(), 3*sizeof(float), n, ode_trimesh_index.data(), n, 3*sizeof(dTriIndex));

    ode_trimesh_geom = dCreateTriMesh(ode_space, ode_trimesh_data, 0, 0, 0);
    dGeomSetBody(ode_trimesh_geom, ode_trimesh_body);
    
    dMassSetTrimeshTotal(&m, 20, ode_trimesh_geom);
    dGeomSetPosition(ode_trimesh_geom, -m.c[0], -m.c[1], -m.c[2]);
    dMassTranslate(&m, -m.c[0], -m.c[1], -m.c[2]);
    
    cout << m.I << endl ;
    
    cout <<"trimesh body " << ode_trimesh_body << endl;
    
    dBodySetMass(ode_trimesh_body, &m);
    dBodySetPosition(ode_trimesh_body, 0, 0.2f, 0);
   
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);
}

void render(int color_mode){
    using namespace glm;
    using namespace std;
    using namespace tinyobj;
    GLuint location, mode_location;
    
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glPolygonOffset(1,1);
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    
    int width = glutGet(GLUT_WINDOW_WIDTH);
    int height = glutGet(GLUT_WINDOW_HEIGHT);
    double aspect = 1.0 * width/height;

    mode_location = glGetUniformLocation(program, "mode");
    glUniform1i(mode_location, 2);
    mat4 V = camera.get_viewing();
    mat4 T(1.0f);
    mat4 P = camera.get_projection(aspect);

    location = glGetUniformLocation(program, "V");
    glUniformMatrix4fv(location, 1, GL_FALSE, value_ptr(V));
    location = glGetUniformLocation(program, "P");
    glUniformMatrix4fv(location, 1, GL_FALSE, value_ptr(P));
    location = glGetUniformLocation(program, "T");
    glUniformMatrix4fv(location, 1, GL_FALSE, value_ptr(T));
    
    
//    GLfloat max_speed = 0.03 ;
    GLfloat speed = 0.0f ;
//    GLfloat acceleration_rate = 1.0f ;
    
    
    if(is_forward_pressed){
        acceleration_rate = 1.0f;
        speed = acceleration_rate * 0.01;
        car_speed += speed ;
        cout << "speed: " << speed << endl ;
        if(is_left_pressed){
            theta += 0.003 ;
        }else if(is_right_pressed){
            theta -= 0.003 ;
        }
        
        if(is_booster_pressed == true){
            int time = 2000;
            cout << "cnt : "<<cnt<<'\n';
            if(cnt > time){
                is_booster_pressed = false;
                accel = 1.0f;
            }
            else if(cnt > time/2){
                accel -= 0.02f;
            }
            else{
                accel += 0.02f;
            }
            cnt ++;
            car_speed += 0.01f * accel;
        }

        
    }else if(is_back_pressed){
        car_speed -= 0.01 ;
        
        if(is_left_pressed){
            theta -= 0.003 ;
        }else if(is_right_pressed){
            theta += 0.003 ;
        }
    }else{
        if(acceleration_rate > 0){
            cout << "acceleration_rate: " << acceleration_rate << endl ;
            acceleration_rate -= 0.01;
            if(acceleration_rate<0){
                acceleration_rate = 0.0f;
            }
            speed = acceleration_rate * 0.001;
            car_speed += speed ;
            cout << "speed: " << speed << endl ;
        }
    }
    
    //    if(isSportsCar){
    //        glUniform1i(UVAR("isSportsCar"), 1);
    //    }else{
    //        glUniform1i(UVAR("isSportsCar"), 0);
    //    }

    if(is_obj_valid){
        for(int i=0; i<NUM_OF_MODELS; ++i){
            glBindVertexArray(vao[i]);
            
            location = glGetUniformLocation(program, "M");
            mat4 M(1.0f);
            
            M = scale(M, vec3(0.5f));
            M = rotate(M, 1.0f, vec3(0.f, 1.f, 0.f));
            M = rotate(M, 0.35f, vec3(1.f, 0.f, 1.f));
            //M = rotate(M, , vec3(0.f, 1.f, 0.f));
            M = translate(M, vec3(0.0f, -0.4f, 0.0f));
            M = translate(M, vec3(0.0f, 0.55f, 0.0f));
            if(i == PATRICK){ // Patrick
                glUniform1i(UVAR("isSportsCar"), 0);
                
                M = rotate(M, theta, vec3(0.f, 1.f, 0.f)) ;
                M = translate(M, vec3(0.0f , 0.0f, car_speed)) ;
                M = translate(M, vec3(0.15f, 0.2f, 0.35f)) ;// move patrick to the car sit
                
                glUniformMatrix4fv(location, 1, GL_FALSE, value_ptr(M));
            }else if(i == CAR){ // Car
                glUniform1i(UVAR("isSportsCar"), 1);
                
                M = rotate(M, theta, vec3(0.f, 1.f, 0.f)) ;
                M = translate(M, vec3(0.0f , 0.0f, car_speed)) ;
                
                glUniformMatrix4fv(location, 1, GL_FALSE, value_ptr(M));
            }else if(i == CITY){ // City
                glUniform1i(UVAR("isSportsCar"), 0);

                //M = rotate(M, theta, vec3(0.f, 1.f, 0.f)) ;
                //M = translate(M, vec3(0.0f , 0.0f, car_speed)) ;
                M = translate(M, vec3(0.0f, 0.0f, -34.5f)) ;
                M = translate(M, vec3(-12.0f, 0.0f, 0.0f)) ;
                glUniformMatrix4fv(location, 1, GL_FALSE, value_ptr(M));
            }
            draw_obj_model(i, color_mode, i+1);
        }
    }
    
    
    glutSwapBuffers();
}

// acceleration = old_velocity + (accelration * change_in_time)

/* event handling functions */
void special_key(int key, int x, int y){
    if(key == GLUT_KEY_LEFT){
        cout << "<--" << endl ;
        is_left_pressed = true ;
    }
    
    if(key == GLUT_KEY_RIGHT){
        cout << "-->" << endl ;
        is_right_pressed = true ;
    }
    
    if(key == GLUT_KEY_UP){
        cout << "FORWARD" << endl ;
        is_forward_pressed = true ;
    }
    
    if(key == GLUT_KEY_DOWN){
        cout << "BACK" << endl ;
        is_back_pressed = true ;
    }
    
    if(key == GLUT_KEY_HOME){
        cout << "HOME" << "\n";
        is_booster_pressed = true ;
        cnt = 0;
    }
}

void special_up(int key, int x, int y){
    if(key == GLUT_KEY_LEFT){
        is_left_pressed = false ;
    }
    
    if(key == GLUT_KEY_RIGHT){
        is_right_pressed = false ;
    }
    
    if(key == GLUT_KEY_UP){
        is_forward_pressed = false ;
    }
    
    if(key == GLUT_KEY_DOWN){
        is_back_pressed = false ;
    }
}




void draw_obj_model(int model_idx, int color_mode, int object_code){
    glUniform1i(UVAR("ColorMode"), color_mode);
    glUniform1i(UVAR("ObjectCode"), object_code);
    
    glBindVertexArray(vao[model_idx]);
    using namespace glm;
    using namespace tinyobj;
    
    auto& _shapes = shapes[model_idx];
    auto& _materials = materials[model_idx];
    auto& _vertex_map = vertex_map[model_idx];
    auto& _material_map = material_map[model_idx];
    auto& _texmap = texmap[model_idx];
    
    for(size_t i = 0; i<_shapes.size(); ++i){
        for(size_t j = 0; j<_material_map[i].size(); ++j){
            int m_id = _material_map[i][j];

            if(m_id < 0){
                glUniform1f(UVAR("n"), 10.0f);
                glUniform3f(UVAR("Ka"), 0.3f, 0.3f, 0.3f);
                glUniform3f(UVAR("Kd"), 1.0f, 1.0f, 1.0f);
                glUniform3f(UVAR("Ks"), 0.8f, 0.8f, 0.8f);
            }
            else{
                glUniform1f(UVAR("n"), _materials[m_id].shininess);
                glUniform3fv(UVAR("Ka"), 1, _materials[m_id].ambient);
                glUniform3fv(UVAR("Kd"), 1, _materials[m_id].diffuse);
                glUniform3fv(UVAR("Ks"), 1, _materials[m_id].specular);
                
                auto texitem = _texmap.find(_materials[m_id].diffuse_texname);
                if(texitem != _texmap.end()){
                    glActiveTexture(GL_TEXTURE0);
                    glBindTexture(GL_TEXTURE_2D, texitem->second);
                    glUniform1i(UVAR("sampler"), 0);
                }
            }
            glDrawArrays(GL_TRIANGLES, _vertex_map[i][j], _vertex_map[i][j+1]-_vertex_map[i][j]);
            
        }
    }
    
}

double dsElapsedTime(){
    static double prev = 0.0;
    double curr = clock() / 1000.0;
    if(!prev) prev = curr;
    double retval = curr - prev;
    prev = curr;
    if(retval > 1.0) retval = 1.0;
    if(retval < dEpsilon) retval = dEpsilon;
    return retval;
}


glm :: mat4 compute_modelling_transf(dBodyID body){
    using namespace glm;
    mat4 M(1.0f);

    const dReal* pos = dBodyGetPosition(body);
    const dReal* rot = dBodyGetRotation(body);

    M[3] = vec4(pos[0], pos[1], pos[2], 1.0f);
    for(int i=0; i<3; ++i){
        for(int j=0; j<3; ++j){
            M[i][j] = rot[j*4+i];
        }
    }

    return M;
}

static void nearCallback(void *data, dGeomID o1, dGeomID o2){
    const int N = 100;
    dContact contact[N];
    int n = dCollide(o1, o2, N, &(contact[0].geom), sizeof(dContact));
    if(n>0){
        for(int i=0; i<n; i++){
            contact[i].surface.mode = dContactSoftERP | dContactSoftCFM;
            contact[i].surface.mu = 0.8;
            contact[i].surface.soft_erp = 0.9;
            contact[i].surface.soft_cfm = 0.01;
            
            dJointID c = dJointCreateContact(ode_world, ode_contactgroup, &contact[i]);
            dBodyID body1 = dGeomGetBody(contact[i].geom.g1);
            dBodyID body2 = dGeomGetBody(contact[i].geom.g2);
            
            dJointAttach(c, body1, body2);
        }
    }
}

void display(){
   double stepsize = 0.005;
    double dt = dsElapsedTime();
    int no_of_steps = (int)ceilf(dt / stepsize);
    for(int i=0; !pause && i<no_of_steps; ++i){
        dSpaceCollide(ode_space, 0, &nearCallback);
        dWorldQuickStep(ode_world, stepsize);
        dJointGroupEmpty(ode_contactgroup);
    }
    
    compute_modelling_transf(ode_sphere_body);
    compute_modelling_transf(ode_trimesh_body);
    
    render(0);
    
    glFlush();
    glutPostRedisplay();
//    glutSwapBuffers();
}


void bind_buffer(GLint buffer, GLvec& vec, int program, const GLchar* attri_name, GLint attri_size){
    glBindBuffer(GL_ARRAY_BUFFER, buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * vec.size(), vec.data(), GL_STATIC_DRAW);
    GLuint location = glGetAttribLocation(program, attri_name);
    glVertexAttribPointer(location, attri_size, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(location);
}

glm::mat4 parallel(double r, double aspect, double n, double f){
    double l = -r;
    double width = 2*r;
    double height = width / aspect;
    double t = height/2;
    double b = -t;
    return glm::ortho(l, r, b, t, n, f);
}

int build_program(){
    ShaderInfo shaders[] = {
        {GL_VERTEX_SHADER, "/Users/dodo4.0/Projects/OpenGL/CG_Term_Project/OpenGLTest/cart.vert"},
        {GL_FRAGMENT_SHADER, "/Users/dodo4.0/Projects/OpenGL/CG_Term_Project/OpenGLTest/cart.frag"},
        {GL_NONE, NULL}
    };

    GLuint program = LoadShaders(shaders);
    glUseProgram(program);
    return program;
}

void mouse (int button, int state, int x, int y){
    if(state == GLUT_UP){
        unsigned char res[4] ;
        int height = glutGet(GLUT_WINDOW_HEIGHT) ;
        glReadPixels(x, height-y, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, &res) ;
        
//        switch(res[0]){
//            case 1: printf("The earth is clicked!\n"); break ;
//            case 2: printf("The moon is clicked\n"); break ;
//        }
    }
    
    button_pressed[button] = state ;
    mouse_pos[0] = x ;
    mouse_pos[1] = y ;
}

static bool has_file(const char* filepath){
    FILE * fp ;
    fp = fopen(filepath, "rb") ;
//    cout << ">>> has_file filepath: " << filepath << " , " << fp << endl ;
    
    if(fp == NULL){
        fclose(fp) ;
        return false ;
    }
    
    return true ;
}


GLuint generate_tex( const char* tex_file_path, GLint min_filter, GLint mag_filter){
    int width, height, num_of_components;
    unsigned char* image = stbi_load(
                                     tex_file_path, &width, &height,
                                     &num_of_components, STBI_default);

    if(!image){
        fprintf(stderr, "Failed to open %s\n", tex_file_path);
        return false;
    }
    GLuint texture_id;
    glGenTextures(1, &texture_id);
    glBindTexture(GL_TEXTURE_2D, texture_id);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, min_filter);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, mag_filter);

    bool is_supported = true;

    switch (num_of_components) {
        case 3:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
            break;

        case 4:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
            break;

        default:
            is_supported = false;
            break;
    }

    if(IS_MIPMAP(min_filter) || IS_MIPMAP(mag_filter))
        glGenerateMipmap(GL_TEXTURE_2D);

    stbi_image_free(image);
    glBindTexture(GL_TEXTURE_2D, 0);

    if(!is_supported){
        fprintf(stderr, "Unsupported image format : %d components\n",
                num_of_components);
        glDeleteTextures(1, &texture_id);
        texture_id = -1;
    }

    return texture_id;
}

bool load_tex(const char* basedir, vector<real_t>& texcoords_out, map<string, size_t>& texmap_out,
                const vector<real_t>& texcoords, const vector<shape_t>& shapes, const vector<material_t>& materials,
                GLint min_filter, GLint mag_filter){
    using namespace std;
    using namespace tinyobj;

    size_t total_num_of_vertices = 0;
    size_t num_of_shapes = shapes.size();

    for(size_t s = 0; s<num_of_shapes; ++s){
        total_num_of_vertices += shapes[s].mesh.indices.size();
    }
    texcoords_out.resize(total_num_of_vertices*2);

    real_t* texcoords_dst_ptr = texcoords_out.data();
    const real_t* texcoords_src_ptr = texcoords.size() > 0 ? texcoords.data() : NULL;

    for(size_t s = 0; s<num_of_shapes; ++s){
        const mesh_t& mesh = shapes[s].mesh;
        size_t num_of_faces = mesh.indices.size() / 3;
        for(size_t f = 0; f<num_of_faces; ++f){
            int idx[3] = {
                mesh.indices[3*f+0].texcoord_index,
                mesh.indices[3*f+1].texcoord_index,
                mesh.indices[3*f+2].texcoord_index
            };
            real_t tc[3][2];
            if(texcoords_src_ptr != NULL){
                if(idx[0] < 0 || idx[1] < 0 || idx[2] < 0){
                    fprintf(stderr, "Invalid texture coordinate index\n");
                    return false;
                }
                for(size_t i = 0; i<3; ++i){
                    memcpy(tc[i], texcoords_src_ptr + idx[i] * 2, sizeof(real_t)*2);
                    tc[i][1] = 1.0f - tc[i][1];
                }
            }
            else{
                tc[0][0] = tc[0][1] = 0;
                tc[1][0] = tc[1][1] = 0;
                tc[2][0] = tc[2][1] = 0;
            }

            memcpy(texcoords_dst_ptr, tc, sizeof(real_t) * 6);
            texcoords_dst_ptr +=6;
        }
    }
    
    
    //2. make a texture
    GLuint texture_id;
    size_t num_of_materials = materials.size();

    for(size_t m = 0; m<num_of_materials; ++m){
        const material_t& mat = materials[m];
        const string& texname = mat.diffuse_texname;
        if(texname.empty()) continue;
        if (MAP_FIND(texmap_out, texname)) continue;

        string full_texpath = texname;
        
        if(!has_file(full_texpath.c_str())){
            full_texpath = basedir + texname;
            
            if(!has_file(full_texpath.c_str())){
                cout << ">>> full_path: " << full_texpath << endl ;
                fprintf(stderr, "Failed to find %s\n", texname.c_str()) ;
                return false ;
            }
        }

        texture_id = generate_tex(full_texpath.c_str(), min_filter, mag_filter);
        if(texture_id < 0)
            return false;

        texmap_out[texname] = texture_id;
    }
    return true;
}


void keyboard(unsigned char key, int x, int y){
    switch(key){
        case 32:
            car_speed = 0 ;
            theta = 0 ;
            is_back_pressed = false ;
            is_forward_pressed = false ;
            is_right_pressed = false ;
            is_left_pressed = false ;
            break ;
    }
}

void motion(int x, int y){ // called back when the user move a mouse pointer within the window
    int modifiers = glutGetModifiers() ;
    int is_alt_active = modifiers & GLUT_ACTIVE_ALT ;
    int is_command_active = modifiers & GLUT_ACTIVE_COMMAND ;
    int is_shift_active = modifiers & GLUT_ACTIVE_SHIFT ;
    
    int w = glutGet(GLUT_WINDOW_WIDTH) ;
    int h = glutGet(GLUT_WINDOW_HEIGHT) ;
    GLfloat dx = 1.f*(x - mouse_pos[0]) / w ;
    GLfloat dy = -1.f*(y - mouse_pos[1]) / h ;
    
    /* 설명
     Mouse Middle Button은 Mouse Left Button + Shift로 설정하였습니다.
     
     Tumble Tool: Alt + Mouse Left Button + Drag
     Track Tool: Shift + Alt + Mouse Left Button + Drag
     Dolly Tool: Shift + Command + Mouse Left Button + Drag
     Zoom Tool: Command + Mouse Left Button + Drag

     */
    
    if(button_pressed[GLUT_LEFT_BUTTON] == GLUT_DOWN && is_alt_active && is_shift_active){ /* Track Tool */
        mat4 VT(1.0f) ;
        VT = transpose(camera.get_viewing()) ;
        camera.eye += vec3(-dx*VT[0] + -dy*VT[1]) ;
        camera.center += vec3(-dx*VT[0] + -dy*VT[1]) ;
    }else if(button_pressed[GLUT_LEFT_BUTTON] == GLUT_DOWN && is_shift_active && is_command_active){ /* Dolly Tool */
        // Mouse Middle Button + Command + Drag
        vec3 disp = camera.eye - camera.center ;
        if(dy > 0){
            camera.eye = camera.center + 0.95f * disp ;
        }else{
            camera.eye = camera.center + 1.05f * disp ;
        }
    }else if(button_pressed[GLUT_LEFT_BUTTON] == GLUT_DOWN && is_command_active){ /* Zoom Tool */
        // Mouse Left Button + Command + Drag
        if(dy > 0){
            camera.zoom_factor *= 0.95f ;
        }else{
            camera.zoom_factor *= 1.05f ;
        }
    }else if(button_pressed[GLUT_LEFT_BUTTON] == GLUT_DOWN && is_alt_active){ /* Tumble Tool */
        vec4 disp(camera.eye - camera.center, 1) ;
        
        GLfloat alpha = 2.0f;
        mat4 V(1.0f), Rx(1.0f), Ry(1.0f), R(1.0f) ;
        
        
        V = camera.get_viewing() ;
        Rx = rotate(mat4(1.0f), alpha*dy, vec3(transpose(V)[0])) ;
        Ry = rotate(mat4(1.0f), -alpha*dx, vec3(0,1,0)) ;
        R = Ry * Rx ;
        camera.eye = camera.center + vec3(R*disp) ;
        camera.up = mat3(R) * camera.up ;
    }
    
    mouse_pos[0] = x ;
    mouse_pos[1] = y ;
//    glutPostRedisplay() ;
}
